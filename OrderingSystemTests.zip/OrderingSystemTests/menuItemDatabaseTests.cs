﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderingSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace OrderingSystem.Tests
{
    [TestClass()]
    public class menuItemDatabaseTests
    {
        menuItemDatabase itemData = new menuItemDatabase();
        OleDbConnection connection = new OleDbConnection();
        OleDbCommand command = new OleDbCommand();

        [TestMethod()]
        public void menuItemDatabaseTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void addItemToMenuDatabaseTest()
        {
            MenuItem item = new MenuItem("Test Item", 10.99, MenuCategory.Entree);
            item.Calories = 500;
            item.Carbs = 50;
            item.Fats = 20;
            item.Proteins = 30;
            item.SodiumContent = 800;
            item.Ingredients = "Test Ingredients";
            item.AllergyInfo = "Test Allergy Info";
             
            MenuCategory cat = MenuCategory.Entree;

            string result = itemData.addItemToMenuDatabase(item, cat);

            Assert.AreEqual("added item", result);
        }

        [TestMethod()]
        public void removeItemFromMenuDatabaseTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void loadFromMenuItemDatabaseTest()
        {
            int expectedRowCount = 5; 

            DataTable actualResult =  menuItemDatabase.loadFromMenuItemDatabase();

            Assert.IsNotNull(actualResult);
            Assert.AreEqual(expectedRowCount, actualResult.Rows.Count);
        }

        [TestMethod()]
        public void LoadMenuItemCategoryToMenuTest()
        {
            MenuCategory category = MenuCategory.Appetizer;
            ListView list = new ListView();
            itemData.LoadMenuItemCategoryToMenu(category, list);
            Assert.IsTrue(list.Items.Count >= 0);
            Assert.IsFalse(list.Items.Count < 0);

         
        }

        [TestMethod()]
        public void AddAllToDatabaseTest()
        {
            DataGridView dataGrid = new DataGridView();
            dataGrid.Columns.Add("Category", "Dessert");
            dataGrid.Columns.Add("Description", "Choclate Cake");
            dataGrid.Columns.Add("Price", "12.50");
            dataGrid.Columns.Add("Calories", "800");
            dataGrid.Columns.Add("Carbs", "200");
            dataGrid.Columns.Add("Fats", "300");
            dataGrid.Columns.Add("Proteins", "50");
            dataGrid.Columns.Add("SodiumContent", "300");
            dataGrid.Columns.Add("Ingredients", "eggs,flower");
            dataGrid.Columns.Add("AllergyInformation", "eggs");

            // add test data
            dataGrid.Rows.Add("Dessert", "Choclate Cake", "12.50", 800, 200, 300, 50, 300, "eggs,flower", "eggs");
            dataGrid.Rows.Add("Drinks", "Pepsi", "8.00", 300, 150, 70.50, 10, 190, "Sugar", "none");

            itemData.AddAllToDatabase(dataGrid);

            // assert
             connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=OrderingSystem.accdb");
            connection.Open();
             command = new OleDbCommand("SELECT COUNT(*) FROM menuItem", connection);
            int count = (int)command.ExecuteScalar();
            connection.Close();

            Assert.AreEqual(2, count);
            Assert.AreNotEqual(5, count);
            




        }

        [TestMethod()]
        public void searchItemForRemovalTest()
        {
            Assert.Fail();
        }
    }
}