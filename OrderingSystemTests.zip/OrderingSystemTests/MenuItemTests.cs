﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderingSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;





namespace OrderingSystem.Tests
{
    [TestClass()]
    public class MenuItemTests
    {
        MenuItem item = new MenuItem();
        

        [TestMethod()]
        public void DisplayCaloriesTest()
        {
            ListViewItem item = new ListViewItem("Cheeseburger");
            item.SubItems.Add("Burger King");
            item.SubItems.Add("300");
            item.SubItems.Add("35");
            item.SubItems.Add("12");
            item.SubItems.Add("15");
            item.SubItems.Add("800");

            MenuItem.DisplayCalories(item);

            double expectedCalories = 300;
            double expectedCarbs = 35;
            double expectedFats = 12;
            double expectedProteins = 15;
            double expectedSodium = 800;

            Assert.AreEqual(expectedCalories, double.Parse(item.SubItems[2].Text));
            Assert.AreEqual(expectedCarbs, double.Parse(item.SubItems[3].Text));
            Assert.AreEqual(expectedFats, double.Parse(item.SubItems[4].Text));
            Assert.AreEqual(expectedProteins, double.Parse(item.SubItems[5].Text));
            Assert.AreEqual(expectedSodium, double.Parse(item.SubItems[6].Text));
            Assert.AreNotEqual(expectedSodium, double.Parse(item.SubItems[4].Text));
            Assert.AreNotEqual(expectedFats, item.SubItems[4].Text);
            Assert.AreNotEqual(expectedCarbs, double.Parse(item.SubItems[6].Text));

        }

        [TestMethod()]

        public void UpdateMenuItemTest()
        {
            DataGridView dataGridView = new DataGridView();
            dataGridView.Columns.Add("ItemName", "ItemName");
            dataGridView.Rows.Add("French Fries");


            ComboBox itemComboBox = new ComboBox();
            itemComboBox.Items.Add("ItemName");
            itemComboBox.SelectedItem = "ItemName";

            TextBox itemText = new TextBox();
            itemText.Text = "Arby's";

            dataGridView.Rows[0].Selected = true;

            MenuItem.UpdateMenuItem(dataGridView, itemComboBox, itemText);

            Assert.AreEqual("Arby's", dataGridView.Rows[0].Cells["ItemName"].Value);
            Assert.AreNotEqual("French Fries", dataGridView.Rows[0].Cells["ItemName"].Value);
            Assert.AreNotEqual("Arby", dataGridView.Rows[0].Cells["ItemName"].Value);
        }
    }
}